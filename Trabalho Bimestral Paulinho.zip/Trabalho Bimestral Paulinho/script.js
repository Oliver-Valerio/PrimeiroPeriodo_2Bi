// Exercício 1 - Triângulos
document.querySelector(".EX1-BT").addEventListener("click", function() {
    const a = Number(document.getElementById("EX1div-input1").value);
    const b = Number(document.getElementById("EX1div-input2").value);
    const c = Number(document.getElementById("EX1div-input3").value);
    const resultado = document.querySelector(".EX1-resposta");

    if (isNaN(a) || isNaN(b) || isNaN(c)) {
        resultado.textContent = "Valores inválidos!";
        return;
    }

    if (a + b > c && a + c > b && b + c > a) {
        if (a === b && b === c) {
            resultado.textContent = "Equilátero";
        } else if (a === b || a === c || b === c) {
            resultado.textContent = "Isósceles";
        } else {
            resultado.textContent = "Escaleno";
        }
    } else {
        resultado.textContent = "Não forma triângulo";
    }
});

// Exercício 2 - IMC
let estadoIMC = "calcular";
document.querySelector(".EX2-BT").addEventListener("click", function() {
    const btn = document.querySelector(".EX2-BT");
    const altura = Number(document.getElementById("EX2div-input1").value);
    const peso = Number(document.getElementById("EX2div-input2").value);
    const resultado = document.querySelector(".EX2-resposta");

    if (estadoIMC === "calcular") {
        if (isNaN(altura) || isNaN(peso)) {
            resultado.textContent = "Valores inválidos!";
            return;
        }
        
        const imc = peso / (altura ** 2);
        resultado.textContent = imc.toFixed(2);
        btn.textContent = "Limpar";
        estadoIMC = "limpar";
    } else {
        document.getElementById("EX2div-input1").value = "";
        document.getElementById("EX2div-input2").value = "";
        resultado.textContent = "Informe os valores";
        btn.textContent = "Calcular";
        estadoIMC = "calcular";
    }
});

// Exercício 3 - Transferência de Veículos
document.querySelector(".EX3-BT").addEventListener("click", function() {
    const ano = Number(document.getElementById("EX3div-input1").value);
    const valor = Number(document.getElementById("EX3div-input2").value);
    const resultado = document.querySelector(".EX3-resposta");

    if (isNaN(ano) || isNaN(valor)) {
        resultado.textContent = "Valores inválidos!";
        return;
    }

    const taxa = ano < 1990 ? 0.01 : 0.015;
    resultado.textContent = `R$ ${(valor * taxa).toFixed(2)}`;
});

// Exercício 4 - Aumento Salarial
document.querySelector(".EX4-BT").addEventListener("click", function () {
    const salario = Number(document.getElementById("EX4div-input1").value);
    const codigo = Number(document.getElementById("EX4div-input2").value);
    const resultado = document.querySelector(".EX4-resultado1");

    if (isNaN(salario) || isNaN(codigo)) {
        resultado.innerHTML = `<h4>⚠️ Informe valores válidos!</h4>`;
        return;
    }

    let percentual;
    let cargo;

    switch (codigo) {
        case 101:
            percentual = 0.10;
            cargo = "Gerente";
            break;
        case 102:
            percentual = 0.20;
            cargo = "Engenheiro";
            break;
        case 103:
            percentual = 0.30;
            cargo = "Técnico";
            break;
        default:
            percentual = 0.40;
            cargo = "Não listado";
            break;
    }

    const aumento = salario * percentual;
    const novoSalario = salario + aumento;

    resultado.innerHTML = `
        <h4>📊 Resultado:</h4>
        <p><strong>Cargo:</strong> ${cargo}</p>
        <p><strong>Percentual de aumento:</strong> ${(percentual * 100)}%</p>
        <p><strong>Salário atual:</strong> R$ ${salario.toFixed(2)}</p>
        <p><strong>Diferença:</strong> R$ ${aumento.toFixed(2)}</p>
        <p><strong>Novo salário:</strong> R$ ${novoSalario.toFixed(2)}</p>
    `;
});


//card 5
function calcularCredito() {
    // Corrigindo os seletores para bater com o HTML
    const saldo = Number(document.getElementById('EX5-input').value);
    const resultado = document.querySelector('.EX5-resultado');

    if (isNaN(saldo) || saldo < 0) {
        resultado.textContent = "❌ Digite um valor válido";
        return;
    }

    let credito;
    if (saldo <= 200) {
        credito = 0;
        resultado.innerHTML = "<span style='color:#e74c3c'>Sem crédito</span>";
    } else if (saldo <= 400) {
        credito = saldo * 0.2;
        resultado.innerHTML = `<span style='color:#27ae60'>Crédito de 20%: R$ ${credito.toFixed(2)}</span>`;
    } else if (saldo <= 600) {
        credito = saldo * 0.3;
        resultado.innerHTML = `<span style='color:#27ae60'>Crédito de 30%: R$ ${credito.toFixed(2)}</span>`;
    } else {
        credito = saldo * 0.4;
        resultado.innerHTML = `<span style='color:#27ae60'>Crédito de 40%: R$ ${credito.toFixed(2)}</span>`;
    }
}

// Vincular o evento ao botão (adicione esta linha no seu código)
document.querySelector('.EX5-BT').addEventListener('click', calcularCredito);


// Exercício 6 - Lanchonete (com cardápio funcional)
document.getElementById("btnCardapio").addEventListener("click", function() {
    alert(`
    🍔 CARDÁPIO 🍔
    100 - Cachorro Quente → R$11,00
    101 - Bauru → R$8,50
    102 - Misto Quente → R$8,00
    103 - Hambúrguer → R$9,00
    104 - Cheeseburger → R$10,00
    105 - Refrigerante → R$4,50
    `);
});

document.querySelector(".EX6-BT").addEventListener("click", function() {
    const codigo = Number(document.getElementById("EX6-input1").value);
    const quantidade = Number(document.getElementById("EX6-input2").value);
    const resultado = document.querySelector(".EX6-resultado");

    if (isNaN(codigo) || isNaN(quantidade)) {
        resultado.textContent = "Valores inválidos!";
        return;
    }

    let preco;
    switch(codigo) {
        case 100: preco = 11.00; break;
        case 101: preco = 8.50; break;
        case 102: preco = 8.00; break;
        case 103: preco = 9.00; break;
        case 104: preco = 10.00; break;
        case 105: preco = 4.50; break;
        default:
            resultado.textContent = "Código inválido!";
            return;
    }

    resultado.textContent = `Total: R$ ${(preco * quantidade).toFixed(2)}`;
});

// Exercício 7 - Pagamentos (com opções funcional)
document.getElementById("btnOpcoes").addEventListener("click", function() {
    alert(`
    💳 OPÇÕES DE PAGAMENTO 💳
    a) À vista em dinheiro/cheque → 10% de desconto
    b) À vista no cartão → 15% de desconto
    c) Em 2x → Preço normal sem juros
    d) Em 3x → Preço normal + 10% de juros
    `);
});

document.querySelector(".EX7-BT").addEventListener("click", function() {
    const preco = Number(document.getElementById("EX7-input1").value);
    const forma = document.getElementById("EX7-input2").value.toLowerCase();
    const resultado = document.querySelector(".EX7-resultado");

    if (isNaN(preco)) {
        resultado.textContent = "Preço inválido!";
        return;
    }

    let total;
    switch(forma) {
        case 'a':
            total = preco * 0.9;
            resultado.textContent = `À vista: R$ ${total.toFixed(2)} (10% off)`;
            break;
        case 'b':
            total = preco * 0.85;
            resultado.textContent = `À vista (cartão): R$ ${total.toFixed(2)} (15% off)`;
            break;
        case 'c':
            total = preco;
            resultado.textContent = `2x de R$ ${(total/2).toFixed(2)} (sem juros)`;
            break;
        case 'd':
            total = preco * 1.1;
            resultado.textContent = `3x de R$ ${(total/3).toFixed(2)} (+10% juros)`;
            break;
        default:
            resultado.textContent = "Forma de pagamento inválida!";
    }
});

// Exercício 8 - Professor
document.querySelector(".EX8-BT").addEventListener("click", function() {
    const nivel = Number(document.getElementById("EX8-input1").value);
    const horas = Number(document.getElementById("EX8-input2").value);
    const resultado = document.querySelector(".EX8-resultado");

    if (isNaN(nivel) || isNaN(horas)) {
        resultado.textContent = "Valores inválidos!";
        return;
    }

    let valorHora;
    switch(nivel) {
        case 1: valorHora = 12; break;
        case 2: valorHora = 17; break;
        case 3: valorHora = 24; break;
        default:
            resultado.textContent = "Nível inválido (1, 2 ou 3)";
            return;
    }

    resultado.textContent = `Salário: R$ ${(valorHora * horas * 4.5).toFixed(2)}`;
});