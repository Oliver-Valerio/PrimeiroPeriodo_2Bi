let inputnota1 = document.querySelector("#inputnota1");
let inputnota2 = document.querySelector("#inputnota2");
let inputnota3 = document.querySelector("#inputnota3");
let inputnota4 = document.querySelector("#inputnota4");
let resultado = document.querySelector("#resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let num1 = Number(inputnota1.value);
    let num2 = Number(inputnota2.value);
    let num3 = Number(inputnota3.value);
    let num4 = Number(inputnota4.value);
   
    if(num1 < num2 && num1 < num3 && num1 < num4){
        resultado.textContent = num1;
    }
    else if(num3 < num4 && num3 < num2 && num2 < num1){
        resultado.textContent = num3;
    }
    else if(num4 < num3 && num4 < num2 && num4 < num1){
        resultado.textContent = num4;
    }   
    else{
        resultado.textContent = num2;
    }
}


btcalcular.onclick = function(){
    calcular();
}