let inputnota1 = document.querySelector("#inputnota1");
let resultado = document.querySelector("#resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let num1 = Number(inputnota1.value);

   
    if(num1 % 2 == 0){
        resultado.textContent = "par"
    }
    else {
        resultado.textContent = "impar"
    }
}


btcalcular.onclick = function(){
    calcular();
}