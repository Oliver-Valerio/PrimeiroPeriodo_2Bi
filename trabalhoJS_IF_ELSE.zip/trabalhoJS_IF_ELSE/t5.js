let inputnota1 = document.querySelector("#inputnota1");
let inputnota2 = document.querySelector("#inputnota2");
let resultado = document.querySelector("#resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let num1 = Number (inputnota1.value);
    let num2 = Number (inputnota2.value);

    if(num1 > num2){
        resultado.textContent = num1
    }else{num2 > num1
        resultado.textContent = num2
    }
}



btcalcular.onclick = function(){
    calcular();
}