let valorum = document.querySelector("#valorum");
let valordois = document.querySelector("#valordois");
let resultadoum = document.querySelector("#resultadoum");
let resultadodois = document.querySelector("#resultadodois");
let resultadotres = document.querySelector("#resultadotres");
let resultadoquatro = document.querySelector("#resultadoquatro");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let num1 = Number (valorum.value);
    let num2 = Number (valordois.value);
    resultadoum.textContent = " SOMA = " + num1 + num2;
    resultadodois.textContent = " SUBTRAÇÃO = " + (num1 - num2);
    resultadotres.textContent = " MULTIPLICAÇÃO = " + num1 * num2;
    resultadoquatro.textContent =  " DIVISÃO = " + num1 / num2;
}

btcalcular.onclick = function(){
    calcular();
}