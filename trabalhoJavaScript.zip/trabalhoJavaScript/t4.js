let saldo = document.querySelector("#saldo")
let btCalculo = document.querySelector("#btCalculo")
let saldoreajustado = document.querySelector("#saldoreajustado")

function calcularporcentagem(){
    let saldonormal = Number (saldo.value);
    saldoreajustado.textContent = ((saldonormal * (1 /100)) + saldonormal);
}

btCalculo.onclick = function(){
    calcularporcentagem();
}