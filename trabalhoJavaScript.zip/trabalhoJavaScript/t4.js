let saldo = document.querySelector("#saldo")
let btCalculo = document.querySelector("#btCalculo")
let saldoreajustado = document.querySelector("#saldoreajustado")

function calcularporcentagem(){
    let saldonormal = Number (saldo.value);
    saldoreajustado.textContent = ((saldonormal * (1 /100)) + saldonormal);
}

function cotagem(){
    let valor1 = (cotagem() / 1) * 100;
    let valor2 = (cotagem() / 2) * 100;
    let valor3 = (cotagem() / 5) * 100;
    let valor4 = (cotagem() / 1) * 100;
}


btCalculo.onclick = function(){
    calcularporcentagem();
}