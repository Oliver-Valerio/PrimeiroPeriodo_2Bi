let num1 = document.querySelector("#num1")
let num2 = document.querySelector("#num2")
let num3 = document.querySelector("#num3")
let resultadoum = document.querySelector("#resultadoum")
let resultadodois = document.querySelector("#resultadodois")
let resultadotres = document.querySelector("#resultadotres")
let resultadoquatro = document.querySelector("#resultadoquatro")
let btcalculo = document.querySelector("#btcalculo")


function calcular(){
    let numeroum = Number (num1.value);
    let numerodois = Number (num2.value);
    let numerotres = Number (num3.value);
    let resultA = (numeroum + numerodois + numerotres) /3 //(MÉDIA ARITMÉTICA)//
    resultadoum.textContent = "MÉDIA ARITMÉTICA = " +resultA;
    return resultA;   
}

function calcular2(){
    let numeroum = Number (num1.value);
    let numerodois = Number (num2.value);
    let numerotres = Number (num3.value);
    let resultB = (numeroum * 3) + (numerodois * 2) + (numerotres * 5) /3 //MÉDIA PONDERADA//
    resultadodois.textContent = "MÉDIA PONDERADA = " + resultB;
    return resultB;
}

function calcular3(){
    let resultC = Number (calcular()) + (calcular2());
    resultadotres.textContent = "SOMA DAS DUAS MÉDIAS = " + resultC;
    return resultC;
}

function calcular4(){
    let resultD = (calcular3()) /2;
    resultadoquatro.textContent = "A MÉDIA DAS MÉDIAS = " + resultD;
    return resultD;
}

    btcalculo.onclick = function(){
        calcular();
        calcular2();
        calcular3();
        calcular4();
}
