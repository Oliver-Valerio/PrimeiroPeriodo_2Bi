let pizzaum = document.querySelector("#pizzaum");
let pizzadois = document.querySelector("#pizzadois");
let pizzatres = document.querySelector("#pizzatres");
let pizzaquatro = document.querySelector("#pizzaquatro");
let refrigerante = document.querySelector("#refrigerante");
let resultadoum = document.querySelector("#resultadoum");
let resultadodois = document.querySelector("#resultadodois");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let num1 = (pizzaum.value);
    let num2 = (pizzadois.value);
    let num3 = (pizzatres.value);
    let num4 = (pizzaquatro.value);
    let refri = (refrigerante.value)
    resultadoum.textContent = num1 + " " + num2 + " "  + num3 + " "  + num4 + " " ;
    resultadodois.textContent = refri * 7 + 12 * 4 + "R$";
}

btcalcular.onclick = function(){
    calcular();
}