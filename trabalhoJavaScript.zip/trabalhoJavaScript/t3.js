let valorkg = document.querySelector("#valorkg")
let quantidadekg = document.querySelector("#quantidadekg")
let resultado = document.querySelector("#resultado")
let btCalculo = document.querySelector("#btCalculo")

function calcularkg(){
    let valorquilos = Number (valorkg.value);
    let tantosquilos = Number (quantidadekg.value);
    resultado.textContent = (valorquilos * tantosquilos);
}

btCalculo.onclick = function(){
    calcularkg();
}