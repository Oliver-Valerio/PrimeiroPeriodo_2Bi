//Faça uma página que tenha dois campos e um botão somar, ao licar no botão exivba o resultado da soma dos dois números informados
//Importando os documentos do html
let numero1 = document.querySelector("#numero1");
let numero2 = document.querySelector("#numero2");
let btSoma = document.querySelector("#btSoma");
let resultado = document.querySelector("#resultado");

function somarNumeros(){
//Adicionando os valores (Não pode ser o mesmo que os de cima)//
    let numeroum = Number (numero1.value);
    let numerodois = Number (numero2.value);
    resultado.textContent = (numeroum + numerodois);
}
//Adicionando função pro botão//
btSoma.onclick = function(){
    somarNumeros();
}
