    let v1 = document.querySelector("#valor1")
    let v2 = document.querySelector("#valor2")
    let resultado = document.querySelector("#resultado")
    let btcalculo = document.querySelector("#btcalculo")

    function compararValores() {
        let num1 = Number(valor1.value);
        let num2 = Number(valor2.value);
      
    if (isNaN(num1) || isNaN(num2)) {
        resultado.textContent = "Por favor, digite dois números válidos.";
      } else if (num1 > num2) {
        resultado.textContent = "O maior valor é: " + num1;
      } else if (num2 > num1) {
        resultado.textContent = "O maior valor é: " + num2;
      } else {
        resultado.textContent = "Os dois valores são iguais.";
      }
    }

    btcalculo.onclick = function() {
        compararValores();
    };