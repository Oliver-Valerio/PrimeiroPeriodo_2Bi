//Faça uma página que receba um valor que é o valor pago, um segundo valor que é o preço do produto e retorne o troco a ser dado
let valorPago = document.querySelector("#valorPago")
let valorProduto = document.querySelector("#valorProduto")
let troco = document.querySelector("#troco")
let btsub = document.querySelector("#btsub")

function subtrairvalores(){
    let pagarvalor = Number (valorPago.value);
    let produtopagar = Number (valorProduto.value)
    troco.textContent = (pagarvalor - produtopagar)
}

btsub.onclick = function(){
    subtrairvalores();
}