let valordolar = document.querySelector("#valordolar")
let resultadoum = document.querySelector("#resultadoum")
let resultadodois = document.querySelector("#resultadodois")
let resultadotres = document.querySelector("#resultadotres")
let resultadoquatro = document.querySelector("#resultadoquatro")
let btcalcular = document.querySelector("#btcalcular")

function calcular(){
    let dolar = Number (valordolar.value);

    resultadoum.textContent = (dolar * 1) / 100 + dolar;
    resultadodois.textContent = (dolar * 2) / 100 + dolar;
    resultadotres.textContent = (dolar * 5) / 100 + dolar;
    resultadoquatro.textContent = (dolar * 10) / 100 + dolar;
}

btcalcular.onclick = function(){
    calcular();
}