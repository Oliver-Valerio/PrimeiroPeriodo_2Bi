let calcularomelete = document.querySelector("#calcularomelete");
let ovos = document.querySelector("#ovos");
let queijo = document.querySelector("#queijo");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let num1 = Number (calcularomelete.value);
    ovos.textContent = num1 * 2 + " ovos";
    queijo.textContent = num1 * 50 + " ,00 g Queijo";
}

btcalcular.onclick = function(){
    calcular();
}