let inputnota1 = document.querySelector("#inputnota1");
let inputnota2 = document.querySelector("#inputnota2");
let resultado = document.querySelector("#resultado");
let btcalcular = document.querySelector("#btcalcular");

function calcular(){
    let nota1 = Number (inputnota1.value);
    let nota2 = Number (inputnota2.value);
    let media = (nota1 + nota2) / 2;
    //APROVADO: MÉDIA 6.0 OU MAIOR
    //REPROVADO: MÉDIA MENOR QUE 6.0

    if(media >= 6.0){
        resultado.textContent = "Parabens voce esta aprovado"
    }else{
        resultado.textContent = "Parabens voce esta reprovado! HAHAHA"
    }
}



btcalcular.onclick = function(){
    calcular();
}